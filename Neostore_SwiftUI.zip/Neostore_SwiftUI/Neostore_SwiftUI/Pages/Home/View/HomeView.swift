//
//  HomeView.swift
//  Neostore_SwiftUI
//
//  Created by webwerks  on 12/01/24.
//

import SwiftUI

struct HomeView: View {
    
    @State private var isSidebarOpened = false
    
    var body: some View {
        ZStack {
            NavigationView {
                ScrollView {
                    VStack {
                        // main content
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppColors.primaryColor)
                    .navigationBarTitleDisplayMode(.automatic)
                    .navigationBarBackButtonHidden()
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button {
                                withAnimation {
                                    isSidebarOpened.toggle()
                                }
                            } label: {
                                Image(systemName: "line.horizontal.3")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .font(.title2)
                                    .foregroundColor(.white)
                            }
                        }
                        ToolbarItem(placement: .principal) {
                            Text("NeoSTORE")
                                .bold()
                                .font(.title)
                                .foregroundColor(.white)
                        }
                    }
                    .toolbarBackground(
                        AppColors.primaryColor,
                        for: .navigationBar
                    )
                }
                .background(.red)
            }
            
            SideBarView(isSidebarVisible: $isSidebarOpened)
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
