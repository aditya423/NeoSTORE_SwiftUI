//
//  SideBarView.swift
//  Neostore_SwiftUI
//
//  Created by webwerks  on 24/01/24.
//

import SwiftUI

struct SideBarView: View {
    
    @Binding var isSidebarVisible: Bool
    var sideBarWidth = UIScreen.main.bounds.size.width * 0.8
    var viewModel = SideBarViewModel()
    
    var body: some View {
        ZStack {
            GeometryReader { _ in
                EmptyView()
            }
            .background(.black.opacity(0.1))
            .opacity(isSidebarVisible ? 1 : 0)
            .animation(.easeInOut.delay(0.2), value: isSidebarVisible)
            .onTapGesture {
                isSidebarVisible.toggle()
            }
            
            HStack(alignment: .top) {
                ZStack(alignment: .top) {
                    Color.black.edgesIgnoringSafeArea(.all)
                    List {
                        ForEach(0..<viewModel.menuData.count+1) { i in
                            if i==0 {
                                VStack {
                                    Image(ImageNames.profileImage.rawValue)
                                        .frame(width: 50, height: 50)
                                        .aspectRatio(contentMode: .fill)
                                    Text("Aditya Ghadge")
                                        .bold()
                                        .font(.title2)
                                    Text("adityasghadge@gmail.com")
                                        .font(.title3)
                                }
                                .listRowBackground(Color.cyan)
                            } else if i==1 {
                                VStack(alignment: .leading) {
                                     HStack {
                                         Image(viewModel.menuImages[i-1])
                                            .resizable()
                                            .frame(width: 30, height: 30)
                                            .aspectRatio(contentMode: .fill)
                                         Text(viewModel.menuData[i-1])
                                         Label("0")
                                    }
                                }
                                .listRowBackground(Color.cyan)
                            } else {
                                VStack(alignment: .leading) {
                                    HStack {
                                        Image(viewModel.menuImages[i-1])
                                            .resizable()
                                            .frame(width: 30, height: 30)
                                            .aspectRatio(contentMode: .fill)
                                        Text(viewModel.menuData[i-1])
                                    }
                                }
                                .listRowBackground(Color.cyan)
                            }
                        }
                    }
                    //.scrollContentBackground(.hidden)
                }
                .frame(width: sideBarWidth)
                .offset(x: isSidebarVisible ? 0 : -sideBarWidth)
                .animation(.default, value: isSidebarVisible)
                Spacer()
            }
        }
    }
}
